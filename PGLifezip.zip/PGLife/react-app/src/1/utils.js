// For development use this:
//export const base_path = "http://127.0.0.1/pglife_steps";

// For production use this:
export const base_path = ".";